utils::globalVariables(c(".", ":=", "dev.off", "lower", "reversed", "svglite", "upper", "value", "vertical_line"))
